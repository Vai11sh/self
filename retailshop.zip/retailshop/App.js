import React, { useState } from 'react'
import './App.css';


function App() {

    const [inputdata,SetInputdata] = useState(
        {
            name:""
            rollNo:""
           
        })


    function changehandle(e) {


        SetInputdata({...inputdata,[e.target.name]:e.target.value})

    }
    return (
        <div className="App">
            <input type="text"  name= 'name' value={inputdata.name} onChange={changehandle } /><br/><br/>
            <input type="text"  name= 'rollNo' value={inputdata.rollNo} onChange={changehandle }/><br/><br/>

            
         </div>

    );

}

export default App;

